# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class AmazonPetCamerasProductsItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    product_name = scrapy.Field()
    product_review_number = scrapy.Field()
    product_stars = scrapy.Field()
    product_rank = scrapy.Field()
    product_stars_distribution = scrapy.Field()
    product_price = scrapy.Field()
    product_links = scrapy.Field()
    product_ratings = scrapy.Field()
    location = scrapy.Field()
    product_asin = scrapy.Field()
    product_brand = scrapy.Field()
    review_link = scrapy.Field()
    pass
